# Lulu Store — Arre Lulu Cleaning

Tienda interactiva en español basada en las tres referencias proporcionadas. Diseño negro, amarillo y rojo, adaptable a escritorio, tablet y móvil.

## Ejecutar

Requiere Node.js 22 o superior y npm.

```bash
npm ci
npm run dev
```

Abre la dirección que muestra Vite en la terminal (normalmente http://localhost:5173).

## Compilar y comprobar

```bash
npm run build
npm run test:sites
npm run preview
```

`dist/client` contiene la versión estática compilada. Puede alojarse en un servidor estático. `dist/server` y `dist/.openai` contienen la adaptación del proyecto para Sites. La publicación y el dominio no están configurados.

## Funciones listas

- Portada con tres diapositivas, avance automático, pausa, controles y gestos táctiles.
- Catálogo con tres paquetes, carrusel con controles y desplazamiento táctil nativo.
- Ficha de producto con galería, selector de paquetes, cantidades y botones funcionales.
- Carrito con altas, bajas, cantidades, subtotales y selección guardada en el navegador.
- Búsqueda, resultados filtrados y estado sin resultados.
- Categorías, recorrido de uso, preguntas desplegables y menú móvil.
- Ruleta animada de demostración con seis resultados; resultado elegido antes de animar y parada alineada con el premio.
- Diálogos accesibles, navegación por teclado y respeto a movimiento reducido.
- Fuentes e imágenes locales: no requiere servicios de imágenes ni fuentes externos en ejecución.

## Conexiones pendientes para venta real

Esta entrega es un frontend funcional. No crea pedidos reales ni cobra dinero. Requiere conectar pasarela de pago, backend de pedidos, inventario, cálculo de envíos y datos comerciales. La ruleta no entrega premios canjeables; para una campaña real se requieren reglas, validación de compras, existencias y resolución del resultado en servidor.

Precios y presentaciones proceden de las referencias del encargo y deben confirmarse antes de vender. No se añadieron reseñas ni cifras de ventas inventadas. Las imágenes generadas son ilustrativas.

## Archivos

- `src/App.jsx`: interfaz y comportamiento.
- `src/catalog.js`: productos, precios, categorías y premios de demostración.
- `src/styles.css`: estilos y adaptación móvil.
- `public/assets`: imágenes optimizadas WebP.
- `assets-originales`: originales PNG editables para futuras versiones.
- `vite.config.mjs`, `package.json`, `package-lock.json`: configuración y dependencias reproducibles.
- `worker`, `scripts`, `tests`, `.openai`: soporte de compilación y alojamiento.

Imágenes creadas con ImageGen a partir de las referencias: producto sobre piedra negra con espuma y luz ámbar; paquetes personales y de distribución; categorías de tenis, gorra, sala y bolso; marca Arre Lulu con fondo transparente. Tipografías Barlow, Barlow Condensed y Permanent Marker mediante Fontsource; iconos Phosphor. Sus licencias están en `LICENSES`.
