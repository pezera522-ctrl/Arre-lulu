export const products = [
  { id:'personal', title:'Uso personal', pieces:2, price:300, previous:350, label:'EL FAVORITO', image:'pack-duo.webp', description:'Uno para tus tenis. Otro para todo lo demás.', detail:'Tu primer encuentro con Arre Lulu. Un par de espumas para sumar la limpieza a tu rutina y tener siempre una a la mano.' },
  { id:'mayoreo', title:'Mayoreo', pieces:30, price:3000, previous:3500, label:'PARA EMPRENDER', image:'pack-mayoreo.webp', description:'La espuma que mueve tu próximo negocio.', detail:'El paquete para quienes quieren llevar Arre Lulu a más personas. Abastece tu punto de venta con 30 piezas de espuma activa.' },
  { id:'distribuidor', title:'Distribuidor', pieces:150, price:7300, previous:7800, label:'VE POR TODO', image:'pack-distribuidor.webp', description:'Piensa en grande. Lleva la limpieza más lejos.', detail:'Una presentación de 150 piezas para distribuir a mayor escala. Elige cuántos paquetes necesitas y arma tu selección.' },
];
export const money = value => new Intl.NumberFormat('es-MX',{style:'currency',currency:'MXN',maximumFractionDigits:0}).format(value);
export const categories = [
  {id:'tenis',title:'Tenis',subtitle:'QUE VUELVAN A ROBAR MIRADAS',image:'category-tenis.webp',text:'Dale atención a ese par que te acompaña a todos lados. Revisa el material y las indicaciones de cuidado antes de aplicar la espuma.'},
  {id:'gorras',title:'Gorras',subtitle:'TU ESTILO, SIEMPRE AL CIEN',image:'category-gorras.webp',text:'Tu gorra favorita también merece su momento. Revisa la etiqueta y prueba primero en un área pequeña y poco visible.'},
  {id:'salas',title:'Salas',subtitle:'QUE TU ESPACIO HABLE POR TI',image:'category-salas.webp',text:'Lleva la rutina de cuidado a tu espacio. Comprueba la compatibilidad con la tapicería y sigue las instrucciones del fabricante.'},
  {id:'bolsos',title:'Bolsos',subtitle:'LOS DETALLES SÍ IMPORTAN',image:'category-bolsos.webp',text:'Cuida lo que llevas contigo. Antes de limpiar cuero, acabados delicados o materiales especiales, consulta sus instrucciones de cuidado.'},
];
export const rewards = [
 {title:'ENVÍO GRATIS',lines:['ENVÍO','GRATIS']}, {title:'10% DE DESCUENTO',lines:['10%','DESCUENTO']}, {title:'GORRA LULU',lines:['GORRA','LULU']}, {title:'ESPUMA GRATIS',lines:['ESPUMA','GRATIS']}, {title:'PREMIO SORPRESA',lines:['PREMIO','SORPRESA']}, {title:'15% DE DESCUENTO',lines:['15%','DESCUENTO']}
];
